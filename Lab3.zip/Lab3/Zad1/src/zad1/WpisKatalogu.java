/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package zad1;

/**
 *
 * @author student
 */
public class WpisKatalogu {
    WpisKatalogu(Produkt produkt, String kod) {
        this.produkt = produkt;
        this.kod = kod;
    }

    public Produkt produkt;
    public String kod;
}
