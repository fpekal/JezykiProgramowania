/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package zad2;

/**
 *
 * @author proxy_lb
 */
public class DostepnaPozycja {
    DostepnaPozycja(int x, int y, int jedzenie) {
        this.x = x;
        this.y = y;
        this.jedzenie = jedzenie;
    }
    
    public int x;
    public int y;
    public int jedzenie;
}
